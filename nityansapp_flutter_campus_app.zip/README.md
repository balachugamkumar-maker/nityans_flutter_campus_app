# NityansApp - Production Flutter Campus App

Run:
1. flutter pub get
2. flutter run
3. flutter build apk --release
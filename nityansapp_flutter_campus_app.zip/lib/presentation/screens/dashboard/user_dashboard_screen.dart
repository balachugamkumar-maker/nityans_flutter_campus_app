class UserDashboardScreen extends StatelessWidget {
  const UserDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppTopBar(
        title: 'Welcome, Aarav Sharma 👋',
        subtitle: 'Computer Science & Engineering • Sem 6',
      ),
      drawer: const AppDrawer(currentRoute: AppRoutes.dashboard),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Pro Banner, Stats Tiles, Action Grid, Featured Notes
          ],
        ),
      ),
    );
  }
}
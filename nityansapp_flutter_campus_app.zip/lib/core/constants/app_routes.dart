class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String dashboard = '/dashboard';
  static const String smartNotes = '/smart-notes';
  static const String viewNotes = '/view-notes';
  static const String downloadNotes = '/download-notes';
  static const String reelFeed = '/reel-feed';
  static const String mcqExam = '/mcq-exam';
  static const String timer = '/timer';
  static const String result = '/result';
  static const String performance = '/performance';
  static const String profile = '/profile';
  static const String subscription = '/subscription';
  static const String settings = '/settings';
  static const String adminDashboard = '/admin-dashboard';
  static const String manageUsers = '/manage-users';
  static const String uploadNotes = '/upload-notes';
  static const String uploadReels = '/upload-reels';
  static const String manageExams = '/manage-exams';
  static const String reports = '/reports';
  static const String privacyPolicy = '/privacy-policy';
  static const String termsConditions = '/terms-conditions';
  static const String aboutUs = '/about-us';
  static const String contactSupport = '/contact-support';
}
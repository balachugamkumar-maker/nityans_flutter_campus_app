import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot> getNotesStream({String? subject}) {
    Query query = _db.collection('notes').orderBy('createdAt', descending: true);
    if (subject != null && subject != 'All Subjects') {
      query = query.where('subject', isEqualTo: subject);
    }
    return query.snapshots();
  }

  Future<void> addCampusNote(Map<String, dynamic> noteData) async {
    await _db.collection('notes').add(noteData);
  }

  Future<void> incrementNoteDownload(String noteId) async {
    await _db.collection('notes').doc(noteId).update({'downloadCount': FieldValue.increment(1)});
  }
}
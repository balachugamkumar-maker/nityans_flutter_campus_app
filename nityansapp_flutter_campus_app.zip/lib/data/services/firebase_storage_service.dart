import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseStorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<String> uploadChapterPdf({required File pdfFile, required String fileName}) async {
    final ref = _storage.ref().child('notes/$fileName');
    final task = await ref.putFile(pdfFile);
    return await task.ref.getDownloadURL();
  }

  Future<String> uploadCampusReelVideo({required File videoFile, required String reelTitle}) async {
    final ref = _storage.ref().child('reels/$reelTitle.mp4');
    final task = await ref.putFile(videoFile);
    return await task.ref.getDownloadURL();
  }
}
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum UserRole { student, faculty, admin }

class FirebaseAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> signIn({required String email, required String password}) async {
    await _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  }

  Future<void> signUp({required String email, required String password, required String fullName}) async {
    final cred = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await _firestore.collection('users').doc(cred.user!.uid).set({
      'email': email,
      'fullName': fullName,
      'role': 'student',
      'isProScholar': false,
    });
  }
}
import 'package:firebase_messaging/firebase_messaging.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  Future<void> initialize() async {
    final messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(alert: true, badge: true, sound: true);
  }

  Future<void> subscribeToSubjectAlerts(String subjectCode) async {
    await FirebaseMessaging.instance.subscribeToTopic(subjectCode.toLowerCase());
  }
}